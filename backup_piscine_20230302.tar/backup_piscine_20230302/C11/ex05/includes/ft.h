/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lidris <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/28 18:35:49 by lidris            #+#    #+#             */
/*   Updated: 2023/03/01 17:43:52 by lidris           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H

# include <unistd.h>

typedef struct t_opp{
	char	*op;
	void	(*func)(int, int);
}	t_opp;
int		ft_isspace(char c);
int		ft_isdigit(char c);
int		ft_atoi(char *str);
void	ft_putchar(char c);
void	ft_putstr(char *str);
void	ft_putnbr(int nb);
void	add(int a, int b);
void	sub(int a, int b);
void	mult(int a, int b);
void	div(int a, int b);
void	mod(int a, int b);
int		ft_strcmp(char *s1, char *s2);
#endif
