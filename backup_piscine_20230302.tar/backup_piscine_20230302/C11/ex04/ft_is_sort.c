/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lidris <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/28 15:20:08 by lidris            #+#    #+#             */
/*   Updated: 2023/03/02 08:07:31 by lidris           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	int	i;
	int	is_sorted_up;

	i = 0;
	is_sorted_up = 1;
	while (i + 1 < length)
	{
		if (!(f(tab[i], tab[i + 1]) <= 0))
		{
			is_sorted_up = 0;
			break ;
		}
		i++;
	}
	i = 0;
	if (!(is_sorted_up))
	{
		while (i + 1 < length)
		{
			if (f(tab[i], tab[i + 1]) < 0)
				return (0);
			i++;
		}
	}
	return (1);
}
