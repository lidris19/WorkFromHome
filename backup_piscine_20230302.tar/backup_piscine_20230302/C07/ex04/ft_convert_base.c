/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lidris <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/22 18:11:31 by lidris            #+#    #+#             */
/*   Updated: 2023/02/28 09:50:55 by lidris           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_index_char(char c, int b, char *base)
{
	int	i;

	i = 0;
	while (i < b)
	{
		if (c == base[i])
			return (i);
		i++;
	}
	return (-1);
}

int	ft_atoi_base(char *str, int b, char *base)
{
	int	i;
	int	sign;
	int	sum;

	i = 0;
	sign = 1;
	sum = 0;
	while ((str[i] >= 9 && str[i] <= 13) || str[i] == ' ')
		i++;
	while ((str[i] == '-' || str[i] == '+'))
	{
		if (str[i] == '-')
			sign *= -1;
		i++;
	}
	while (ft_index_char(str[i], b, base) >= 0)
	{
		sum = sum * b + (ft_index_char(str[i], b, base));
		i++;
	}
	return (sum * sign);
}

int	ft_is_valid_base(char *base)
{
	int	j;
	int	k;

	j = 0;
	while (base[j])
		j++;
	if (j < 2)
		return (0);
	j = 0;
	while (base[j])
		if (base[j] == '-' || base[j] == '+'
			|| base[j] < '!' || base[j++] > '~')
			return (0);
	j = 0;
	while (base[j + 1])
	{
		k = j;
		while (base[++k])
		{
			if (base[j] == base[k])
				return (0);
		}
		j++;
	}
	return (1);
}
