/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lidris <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/22 18:50:31 by lidris            #+#    #+#             */
/*   Updated: 2023/02/22 19:19:34 by lidris           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str);
int	ft_atoi_base(char *str, int b, char *base);
int	ft_is_valid_base(char *base);

char	*write_nbr(int nbr, int nb_len, char *nbr_b, char *base)
{
	int	digit;
	int	b;

	b = ft_strlen(base);
	nbr_b[nb_len] = '\0';
	while (--nb_len >= 0)
	{
		if (nbr <= -b || nbr >= b)
		{
			digit = (nbr % b) * ((nbr > 0) - (nbr < 0));
			nbr_b[nb_len] = base[digit];
		}
		else
		{
			digit = nbr * ((nbr > 0) - (nbr < 0));
			nbr_b[nb_len] = base[digit];
			if (nbr < 0)
				nbr_b[--nb_len] = '-';
		}
		nbr /= b;
	}
	return (nbr_b);
}

char	*ft_itoa_base(int nbr, int b, char *base)
{
	int		is_neg;
	int		nb_len;
	int		temp;
	char	*nbr_b;

	is_neg = 0;
	nb_len = 0;
	temp = nbr;
	if (nbr < 0)
		is_neg = 1;
	while (temp != 0)
	{
		temp /= b;
		nb_len++;
	}
	nb_len += is_neg;
	nbr_b = malloc((nb_len + 1) * sizeof(char));
	if (!nbr_b)
		return (NULL);
	return (write_nbr(nbr, nb_len, nbr_b, base));
}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	char	*nbr_cpy;
	int		decimal;
	int		len_f;
	int		len_t;

	if (nbr == NULL || base_from == NULL || base_to == NULL)
		return (NULL);
	len_f = ft_strlen(base_from);
	len_t = ft_strlen(base_to);
	if (!ft_is_valid_base(base_from) || !ft_is_valid_base(base_to))
		return (NULL);
	decimal = ft_atoi_base(nbr, len_f, base_from);
	nbr_cpy = ft_itoa_base(decimal, len_t, base_to);
	if (!nbr_cpy)
		return (NULL);
	return (nbr_cpy);
}
