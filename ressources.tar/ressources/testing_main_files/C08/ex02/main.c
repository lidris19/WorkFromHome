#include <stdio.h>
#include "ft_abs.h"

int	main(void)
{
	int x = -65;
	int y = ABS(x);

	printf("x = %d, y = %d", x, y);
	return (0);
}

