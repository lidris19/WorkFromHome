#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void ft_foreach(int *tab, int length, void (*f)(int));
int *ft_map(int *tab, int length, int(*f)(int));
int	ft_any(char **tab, int(*f)(char*));
int ft_count_if(char **tab, int length, int(*f)(char*));
int	ft_is_sort(int *tab, int length, int(*f)(int, int));

//// === Ex00 ===
// void ft_putnbr(int n)
// {
//     printf("%d ", n);
// }

// int main()
// {
//     int tab[] = {1, 2, 3, 4, 5};
//     int length = sizeof(tab) / sizeof(tab[0]);
//     ft_foreach(tab, length, &ft_putnbr);
//     return 0;
// }
//// ================================
//// ================================
//// === Ex01 ===
// int square(int x) {
//     return x * x;
// }

// int main() {
//     int input[] = {1, 2, 3, 4, 5};
//     int length = sizeof(input) / sizeof(int);
//     int *output = ft_map(input, length, square);
//     for (int i = 0; i < length; i++) {
//         printf("%d ", output[i]);  // Prints "1 4 9 16 25 "
//     }
//     free(output);  // Don't forget to free the memory!
//     return 0;
// }
//// ================================
//// ================================
//// === Ex02 ===
// int	is_uppercase(char *str)
// {
// 	int i;

// 	i = 0;
// 	while (str[i])
// 	{
// 		if (str[i] >= 'A' && str[i] <= 'Z')
// 			return (1);
// 		i++;
// 	}
// 	return (0);
// }

// int main(void)
// {
// 	char *tab[] = {"hello", "world", "goodbye", NULL};
// 	if (ft_any(tab, &is_uppercase))
// 		printf("At least one uppercase string was found.\n");
// 	else
// 		printf("No uppercase strings found.\n");
// 	return (0);
// }
//// ================================
//// ================================
//// === Ex03 ===
// int contains_a(char *str)
// {
//     while (*str) {
//         if (*str == 'a') {
//             return 1;
//         }
//         str++;
//     }
//     return 0;
// }

// int main()
// {
//     char *arr[] = {"apple", "banana", "cherry", "date", "elderberry", NULL};
//     int count = ft_count_if(arr, 5, contains_a);
//     printf("Number of strings that contain the letter 'a': %d\n", count);
//     return 0;
// }
//// ================================
//// ================================
//// === Ex04 ===
// int	ascending(int a, int b)
// {
// 	return (a - b);
// }

// int	descending(int a, int b)
// {
// 	return (b - a);
// }

// int	main(void)
// {
// 	int	tab1[] = {1, 2, 3, 4, 5};
// 	int	tab2[] = {5, 4, 3, 2, 1};
// 	int	tab3[] = {1, 2, 3, 5, 4};
// 	int	tab4[] = {1, 1, 1, 1, 1};
// 	int	tab5[] = {3};
// 	int	tab6[] = {};

// 	if (ft_is_sort(tab1, 5, &ascending))
// 		printf("Tab1 is sorted in ascending order.\n");
// 	else
// 		printf("Tab1 is not sorted in ascending order.\n");

// 	if (ft_is_sort(tab2, 5, &descending))
// 		printf("Tab2 is sorted in descending order.\n");
// 	else
// 		printf("Tab2 is not sorted in descending order.\n");

// 	if (ft_is_sort(tab3, 5, &ascending))
// 		printf("Tab3 is sorted in ascending order.\n");
// 	else
// 		printf("Tab3 is not sorted in ascending order.\n");

// 	if (ft_is_sort(tab4, 5, &ascending))
// 		printf("Tab4 is sorted in ascending order.\n");
// 	else
// 		printf("Tab4 is not sorted in ascending order.\n");

// 	if (ft_is_sort(tab5, 1, &ascending))
// 		printf("Tab5 is sorted in ascending order.\n");
// 	else
// 		printf("Tab5 is not sorted in ascending order.\n");

// 	if (ft_is_sort(tab6, 0, &ascending))
// 		printf("Tab6 is sorted in ascending order.\n");
// 	else
// 		printf("Tab6 is not sorted in ascending order.\n");

// 	return (0);
// }
//// ================================
//// ================================
//// === Ex05 ===

//// ================================
//// ================================
//// === Ex06 ===

//// ================================
//// ================================
//// === Ex07 ===

//// ================================
//// ================================
// // === Ex08 ===

//// ================================
//// ================================
// // === Ex09 ===

//// ================================
//// ================================
// // === Ex10 ===

//// ================================
//// ================================
// === Ex11 ===

//// ================================
//// ================================
// === Ex12 ===

//// ================================
//// ================================