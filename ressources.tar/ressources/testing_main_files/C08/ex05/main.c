/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lidris <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/27 13:09:10 by lidris            #+#    #+#             */
/*   Updated: 2023/02/28 10:08:09 by lidris           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_stock_str.h"
#include <stdlib.h>

struct s_stock_str	*ft_strs_to_tab(int ac, char **av);
void				ft_show_tab(struct s_stock_str *par);

int main(void)
{
	char *strs[] = {"Hello", "my", "!", "friend", NULL};
	struct s_stock_str *tab = ft_strs_to_tab(4, strs);
	if (tab == NULL)
	{
		// Handle the error
		return 1;
	}
	ft_show_tab(tab);
	// Free the allocated memory
	for (int i = 0; i < 3; i++)
	{
		free(tab[i].copy);
	}
	free(tab);
	return 0;
}

