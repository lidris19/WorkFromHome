/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lidris <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/28 17:37:04 by lidris            #+#    #+#             */
/*   Updated: 2023/03/01 17:44:56 by lidris           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

t_opp	*get_opptab(void)
{
	static t_opp	g_opptab[] = {{"+", &add}, {"-", &sub},
	{"*", &mult}, {"/", &div}, {"%", &mod}};

	return (g_opptab);
}

int	main(int argc, char **argv)
{
	int		a;
	int		b;
	int		op;
	t_opp	*opptab;

	if (argc == 4)
	{
		a = ft_atoi(argv[1]);
		b = ft_atoi(argv[3]);
		opptab = get_opptab();
		op = 0;
		while (op < 5 && ft_strcmp(opptab[op].op, argv[2]) != 0)
			op++;
		if (op < 5)
		{
			opptab[op].func(a, b);
		}
		else
		{
			ft_putnbr(0);
			ft_putchar('\n');
		}
	}
	return (0);
}
